﻿namespace NetProvider.Network.Inter
{
    public interface IWebNetwork
    {

        //X509CertificateCollection CertificateCollection { get; set; }
    }
}
