﻿namespace NetProvider.Core.Channels
{
    public interface IServiceChannel
    {
        object Invok(Parameters parameters);
    }
}
